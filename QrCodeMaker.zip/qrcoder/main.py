import customtkinter
from tkinter import *
import qrcode
from PIL import Image



app= customtkinter.CTk() 
app.geometry("400x500")
app.title("qrcoder")
customtkinter.set_appearance_mode("dark")
customtkinter.set_default_color_theme("blue")
app.resizable(False,False)
app.iconbitmap("qrlogo.ico")



def clickmake(): 
    thelink = textvarlink.get()
    img = qrcode.make(thelink)
    img.show()


def clickshow():
    thelink = textvarlink.get()
    img = qrcode.make(thelink)
    img.save(f"{thelink}.png")\

    



lbllink = customtkinter.CTkLabel(app, text = " enter link/title ").pack()

lblspace1 = customtkinter.CTkLabel(app, text = "    ").pack()

textvarlink = StringVar()
entrylink = customtkinter.CTkEntry(app, textvariable=textvarlink).pack()

lblspace2 = customtkinter.CTkLabel(app, text = "    ").pack()

btnlink = customtkinter.CTkButton(app, text= "show", command = clickmake).pack()

btnshow = customtkinter.CTkButton(app, text= "save", command = clickshow).pack()





app.mainloop()