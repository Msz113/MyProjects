import requests
import customtkinter
from tkinter import *
from bs4 import BeautifulSoup
from PIL import Image
app= customtkinter.CTk() 
app.geometry("600x400")
app.title("DigiConvert")
customtkinter.set_appearance_mode("dark")
customtkinter.set_default_color_theme("blue")
app.resizable(False,False)
app.iconbitmap("icn.ico")



def convert(a,b):
    a = a
    b = b
    result = a/b
    lbl1.configure(text= str(result))


#------------------------------------------------------------------------
fonta1=customtkinter.CTkFont(family='C:/Windows/Fonts/BTITRBD_0.TTF', size=20)

bitcoin = customtkinter.CTkImage(light_image=Image.open("coin/bitcoin.png"))
doge = customtkinter.CTkImage(light_image=Image.open("coin/dogecoin.png"))
solana = customtkinter.CTkImage(light_image=Image.open("coin/solana.png"))
ton = customtkinter.CTkImage(light_image=Image.open("coin/ton.png"))
ethereum = customtkinter.CTkImage(light_image=Image.open("coin/ethereum.png"))

#------------------------------------------------------------------------

response = requests.get("https://www.tgju.org/profile/crypto-ethereum")
response.content


soup = BeautifulSoup(response.text, "html.parser")
span = soup.find('span', {'data-col': "info.last_trade.PDrCotVal"})

ethereumc = span.text



#------------------------------------------------------------------------
response = requests.get("https://www.tgju.org/profile/crypto-bitcoin")
response.content


soup = BeautifulSoup(response.text, "html.parser")
span = soup.find('span', {'data-col': "info.last_trade.PDrCotVal"})

bitcoinc = span.text


#------------------------------------------------------------------------
response = requests.get("https://www.tgju.org/profile/crypto-dogecoin")
response.content


soup = BeautifulSoup(response.text, "html.parser")
span = soup.find('span', {'data-col': "info.last_trade.PDrCotVal"})

dogec = span.text

#------------------------------------------------------------------------
response = requests.get("https://www.tgju.org/profile/crypto-solana")
response.content


soup = BeautifulSoup(response.text, "html.parser")
span = soup.find('span', {'data-col': "info.last_trade.PDrCotVal"})

solanac = span.text



#------------------------------------------------------------------------
response = requests.get("https://www.tgju.org/profile/crypto-toncoin")
response.content


soup = BeautifulSoup(response.text, "html.parser")
span = soup.find('span', {'data-col': "info.last_trade.PDrCotVal"})

toncoinc = span.text

#...........................................................................................



response = requests.get("https://www.tgju.org/profile/price_dollar_rl")
response.content


soup = BeautifulSoup(response.text, "html.parser")
span = soup.find('span', {'data-col': "info.last_trade.PDrCotVal"})

dollarRLc = span.text




#=-=-=-=--=----=-=-=-=----=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-



av = StringVar()
bv = StringVar()



def intorl(x):
    x = x
    y = x*float(dollarRLc.replace(',', ''))
    return y




def getobj():
    avv = av.get()
    bvv = bv.get()
    if avv == "toncoin":
        avv1 = float(toncoinc.replace(',', ''))
    if bvv == "toncoin":
        bvv1 = float(toncoinc.replace(',', ''))

    if avv == "solana":
        avv1 = float(solanac.replace(',', ''))
    if bvv == "solana":
        bvv1 = float(solanac.replace(',', ''))

    if avv == "dogecoin":
        avv1 = float(dogec.replace(',', ''))
    if bvv == "dogecoin":
        bvv1 = float(dogec.replace(',', ''))

    if avv == "ethereum":
        avv1 = float(ethereumc.replace(',', ''))
    if bvv == "ethereum":
        bvv1 = float(ethereumc.replace(',', ''))

    if avv == "bitcoin":
        avv1 = float(bitcoinc.replace(',', ''))
    if bvv == "bitcoin":
        bvv1 = float(bitcoinc.replace(',', ''))

    convert(avv1, bvv1)




etr1 = customtkinter.CTkComboBox(app, state='readonly',values=["toncoin", "solana", "bitcoin", "ethereum", "dogecoin"], variable=av)
etr1.place(x= 100, y = 50)
etr2 = customtkinter.CTkComboBox(app, state='readonly',values=["toncoin", "solana", "bitcoin", "ethereum", "dogecoin"], variable=bv)
etr2.place(x= 400, y = 50)
lbl1 = customtkinter.CTkLabel(app, text = "Covert To").place(x = 300, y = 50)
btn1 = customtkinter.CTkButton(app,text = "Covert", command=getobj)
btn1.place(x = 200, y = 100)
lbl1 = customtkinter.CTkLabel(app, text= '')
lbl1.place(x = 350, y = 100)

Btc = intorl(float(bitcoinc.replace(',','')))
lblbtc = customtkinter.CTkLabel(app, text = '', image= bitcoin).place(x = 100, y = 200)
lblbtc1 = customtkinter.CTkLabel(app, text = bitcoinc + "$").place(x = 120, y = 200)
lblbtc2 = customtkinter.CTkLabel(app, text = str(Btc) + "Rial").place(x = 220, y = 200)


Ton = intorl(float(toncoinc.replace(',','')))
lblton = customtkinter.CTkLabel(app, text = '', image= ton).place(x = 100, y = 230)
lblton1 = customtkinter.CTkLabel(app, text = toncoinc + "$").place(x = 120, y = 230)
lblton2 = customtkinter.CTkLabel(app, text = str(Ton) + "Rial").place(x = 220, y = 230)

Sol = intorl(float(solanac.replace(',','')))
lblsol = customtkinter.CTkLabel(app, text = '', image= solana).place(x = 100, y = 260)
lblsol1 = customtkinter.CTkLabel(app, text = solanac + "$").place(x = 120, y = 260)
lblsol2 = customtkinter.CTkLabel(app, text = str(Sol) + "Rial").place(x = 220, y = 260)

Doge = intorl(float(dogec.replace(',','')))
lbldoge = customtkinter.CTkLabel(app, text = '', image= doge).place(x = 100, y = 290)
lbldoge1 = customtkinter.CTkLabel(app, text = dogec + "$").place(x = 120, y = 290)
lbldoge2 = customtkinter.CTkLabel(app, text = str(Doge) + "Rial").place(x = 220, y = 290)

Eth = intorl(float(ethereumc.replace(',','')))
lbleth = customtkinter.CTkLabel(app, text = '', image= ethereum).place(x = 100, y = 320)
lbleth1 = customtkinter.CTkLabel(app, text = ethereumc + "$").place(x = 120, y = 320)
lbleth2 = customtkinter.CTkLabel(app, text = str(Eth) + "Rial").place(x = 220, y = 320)


#----------------------------------------------------------------------------------------

app.mainloop()
